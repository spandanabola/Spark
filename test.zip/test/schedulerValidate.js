else if (app.test_suites[counter].unitTest.configuration.responseType === "Application/json") {
                        console.log("inside json");
                        if (isJson(body)) {
                            console.log("valid json");
                            console.log("**************************");
                            console.log(app.test_suites[counter].unitTest.configuration.jsonData);
                            body = JSON.parse(body);
                            if (body.constructor === {}.constructor) {
                                for (var i = 0; i < app.test_suites[counter].unitTest.configuration.jsonData.length; i++) {
                                    console.log("inside for loop " + app.test_suites[counter].unitTest.configuration.jsonData.length);
                                    keyExist = false;
                                    for (var key in body) {
                                        console.log(key);
                                        if (key == app.test_suites[counter].unitTest.configuration.jsonData[i].key) {
                                            keyExist = true
                                        }
                                    }
                                    if (keyExist == false) {
                                        throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                    } else {

                                        console.log("key present " + app.test_suites[counter].unitTest.configuration.jsonData[i].key);
                                        var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase();
                                        if (app.test_suites[counter].unitTest.configuration.jsonData[i].type !== "") {
                                            if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                if (value === 'false') {
                                                    assert.deepEqual(body[app.test_suites[counter].unitTest.configuration.jsonData[i].key], false, "response data is not matched");
                                                } else if (value === 'true') {
                                                    assert.deepEqual(body[app.test_suites[counter].unitTest.configuration.jsonData[i].key], true, "response data is not matched");
                                                } else if (value === 'null') {
                                                    assert.deepEqual(body[app.test_suites[counter].unitTest.configuration.jsonData[i].key], null, "response data is not matched");
                                                } else {
                                                    assert.deepEqual(body[app.test_suites[counter].unitTest.configuration.jsonData[i].key], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                }

                                            }
                                            else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                if (body[app.test_suites[counter].unitTest.configuration.jsonData[i].key] == null || body[app.test_suites[counter].unitTest.configuration.jsonData[i].key] == "") {
                                                    throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + "key value is not present");
                                                } else {
                                                    if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                        if ((body[app.test_suites[counter].unitTest.configuration.jsonData[i].key] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                            console.log("matched");
                                                            //containMsg = ""
                                                        } else {
                                                            containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                        }
                                                    }

                                                }
                                            }

                                        }
                                    }
                                }

                            } else if (body.constructor === [].constructor) {
                                for (var j = 0; j < body.length; j++) {
                                    for (var i = 0; i < app.test_suites[counter].unitTest.configuration.jsonData.length; i++) {
                                        console.log("inside for loop " + app.test_suites[counter].unitTest.configuration.jsonData.length);
                                        keyExist = false;
                                        for (var key in body[j]) {
                                            console.log(key);
                                            if (key == app.test_suites[counter].unitTest.configuration.jsonData[i].key) {
                                                keyExist = true
                                            }
                                        }
                                        if (keyExist == false) {
                                            throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                        } else {
                                            console.log("key present " + app.test_suites[counter].unitTest.configuration.jsonData[i].key);
                                            console.log(app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase());
                                            var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase()

                                            if (app.test_suites[counter].unitTest.configuration.jsonData[i].type != "") {
                                                if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                    if (value === 'false') {
                                                        assert.deepEqual(body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key], false, "response data is not matched");
                                                    } else if (value === 'true') {
                                                        assert.deepEqual(body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key], true, "response data is not matched");
                                                    } else if (value === 'null') {
                                                        assert.deepEqual(body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key], null, "response data is not matched");
                                                    } else {
                                                        assert.deepEqual(body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                    }

                                                }
                                                else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                    if (body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key] == null || body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key] == "") {
                                                        throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + "key value is not present");
                                                    } else {
                                                        if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                            if ((body[j][app.test_suites[counter].unitTest.configuration.jsonData[i].key] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                                console.log("matched");
                                                                //containMsg = ""
                                                            } else {
                                                                containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                            }
                                                        }

                                                    }
                                                }

                                            }


                                        }
                                    }
                                }
                            }

                            app.test_suites[counter].status = "Successfull";
                            app.test_suites[counter].statusMsg.push({ "time": new Date(), "message": "Successfull" });
                            app.test_suites[counter].unitTest.responseData = JSON.stringify(body);
                            if (counter + 1 < app.test_suites.length) {
                                hitApi(app.test_suites[counter + 1], app, counter + 1);
                            } else {
                                //server store
                                saveTest(app);

                            }
                        } else {
                            throw Error("reponse data is not valid json");
                        }
                    }