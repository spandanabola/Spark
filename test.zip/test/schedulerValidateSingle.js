console.log(body);
                console.log(typeof (body));
                responseBody = body;
                console.log("$$$$$$$$$$$");
                if (app.test_suites[counter].unitTest.configuration.statusCode === "") {
                    app.test_suites[counter].unitTest.configuration.statusCode = null;
                } else {

                };
                if (app.test_suites[counter].unitTest.configuration.statusCode != null) {
                    console.log("inside status check");
                    assert.deepEqual(statusCode, app.test_suites[counter].unitTest.configuration.statusCode, "response status is not matched with expected");
                }
                else if (app.test_suites[counter].unitTest.configuration.statusCode === null) {
                    console.log("inside status check");
                    assert.deepEqual(statusCode, 200, statusText);
                } else {

                };
                if (app.test_suites[counter].unitTest.configuration.responseType === "") {
                    app.test_suites[counter].unitTest.configuration.responseType = null;
                } else {

                };
                if (app.test_suites[counter].unitTest.configuration.responseType != null) {
                    if (app.test_suites[counter].unitTest.configuration.responseType === 'Plain/text') {
                        console.log("inside string");
                        if (isJson(body)) {
                            throw Error("reponse data is not string");
                        } else {
                            assert.deepStrictEqual(typeof (body), typeof ("string"), "type of response data is not matched");
                            if ((body + "") == "" || body == null) {
                                throw Error("reponse data is empty or null");
                            } else {
                                if (app.test_suites[counter].unitTest.configuration.textData.type != null) {
                                    if (app.test_suites[counter].unitTest.configuration.textData.type === "Exact Match") {
                                        assert.deepEqual(body, app.test_suites[counter].unitTest.configuration.textData.value, "response data is not matched");
                                    }
                                    else if (app.test_suites[counter].unitTest.configuration.textData.type === "Contains") {

                                        if (app.test_suites[counter].unitTest.configuration.textData.value != "") {
                                            if ((body + "").includes(app.test_suites[counter].unitTest.configuration.textData.value)) {
                                                console.log("matched");
                                            } else {
                                                throw Error("reponse data is not matched");
                                            }
                                        }



                                    }
                                }
                            }

                        }


                        app.test_suites[counter].status = "Successfull";
                        app.test_suites[counter].statusMsg.push({ "time": new Date(), "message": "Successfull" });
                        app.test_suites[counter].unitTest.responseData = responseBody;
                        if (counter + 1 < app.test_suites.length) {
                            hitApi(app.test_suites[counter + 1], app, counter + 1);
                        } else {
                            //server store
                            saveTest(app);

                        }
                    }
                    else if (app.test_suites[counter].unitTest.configuration.responseType === "Application/json") {
                        console.log("inside json");
                        if (isJson(body)) {
                            console.log("valid json");
                            console.log("**************************");
                            console.log(app.test_suites[counter].unitTest.configuration.jsonData);
                            body = JSON.parse(body);
                            if (body.constructor === {}.constructor) {
                                for (var i = 0; i < app.test_suites[counter].unitTest.configuration.jsonData.length; i++) {
                                    console.log("inside for loop " + app.test_suites[counter].unitTest.configuration.jsonData.length);
                                    keyArray = app.test_suites[counter].unitTest.configuration.jsonData[i].key.split(".");
                                    console.log("==========================");
                                    console.log(keyArray);
                                    var dupBody = body;
                                    for (var k = 0; k < keyArray.length; k++) {
                                        console.log(dupBody);
                                        console.log(keyArray[k]);
                                        if (dupBody.constructor === {}.constructor) {
                                            keyExist = false;
                                            for (var key in dupBody) {
                                                console.log(key);
                                                if (key == keyArray[k]) {
                                                    keyExist = true;
                                                    break;
                                                }
                                            }
                                            if (keyExist == false) {
                                                throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                            } else {
                                                if (k + 1 == keyArray.length) {
                                                    console.log("equalled");
                                                    console.log(dupBody[keyArray[k]]);
                                                    console.log("key present " + keyArray[k]);
                                                    var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase();
                                                    if (app.test_suites[counter].unitTest.configuration.jsonData[i].type !== "") {
                                                        if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                            if (value === 'false') {
                                                                assert.deepEqual(dupBody[keyArray[k]], false, "response data is not matched");
                                                            } else if (value === 'true') {
                                                                assert.deepEqual(dupBody[keyArray[k]], true, "response data is not matched");
                                                            } else if (value === 'null') {
                                                                assert.deepEqual(dupBody[keyArray[k]], null, "response data is not matched");
                                                            } else {
                                                                assert.deepEqual(dupBody[keyArray[k]], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                            }

                                                        }
                                                        else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                            if (dupBody[keyArray[k]] == null || body[keyArray[k]] == "") {
                                                                throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key value is not present");
                                                            } else {
                                                                if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                                    if ((dupBody[keyArray[k]] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                                        console.log("matched");
                                                                        //containMsg = ""
                                                                    } else {
                                                                        containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                                    }
                                                                }

                                                            }

                                                        }

                                                    }
                                                } else {
                                                    dupBody = dupBody[keyArray[k]];
                                                    if (dupBody.constructor === "hello".constructor) {
                                                        throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is not present");
                                                    }
                                                    console.log("dupBody********");
                                                    console.log(dupBody);
                                                }
                                            }
                                        } else if (dupBody.constructor === [].constructor) {

                                            //console.log("k value is "+k+" "+keyArray[k]+" "+keyArray.length);
                                            //var keyArr = [];
                                            keyArr = [];
                                            for (var m = 0; keyArray.length > k; m++) {
                                                console.log("k value is " + k + " " + keyArray[k] + " " + keyArray.length);
                                                keyArr.push(keyArray[k]);
                                                k = k + 1;
                                            }
                                            for (var j = 0; j < dupBody.length; j++) {
                                                console.log("inside for loop " + dupBody.length);
                                                //keyArray = req.body.unitTest.configuration.jsonData[i].key.split(".");
                                                console.log("==========================");

                                                //console.log(keyArray);
                                                dup = dupBody[j];
                                                console.log("dup==========================");
                                                console.log(dup);
                                                console.log("keyArr length " + keyArr.length);
                                                for (var m = 0; m < keyArr.length; m++) {
                                                    keyExist = false;
                                                    for (var key in dup) {
                                                        console.log(key);
                                                        if (key == keyArr[m]) {
                                                            keyExist = true;
                                                            break;
                                                        }
                                                    }

                                                    if (keyExist == false) {
                                                        throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                                    } else {
                                                        if (m + 1 == keyArr.length) {
                                                            console.log("equalled");
                                                            console.log(dupBody[keyArray[k]]);
                                                            console.log("key present " + keyArray[k]);
                                                            var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase();
                                                            if (app.test_suites[counter].unitTest.configuration.jsonData[i].type !== "") {
                                                                if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                                    if (value === 'false') {
                                                                        assert.deepEqual(dup[keyArr[m]], false, "response data is not matched");
                                                                    } else if (value === 'true') {
                                                                        assert.deepEqual(dup[keyArr[m]], true, "response data is not matched");
                                                                    } else if (value === 'null') {
                                                                        assert.deepEqual(dup[keyArr[m]], null, "response data is not matched");
                                                                    } else {
                                                                        assert.deepEqual(dup[keyArr[m]], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                                    }

                                                                }
                                                                else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                                    if (dup[keyArr[m]] == null || dup[keyArr[m]] == "") {
                                                                        throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key value is not present");
                                                                    } else {
                                                                        if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                                            if ((dup[keyArr[m]] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                                                console.log("matched");
                                                                                //containMsg = ""
                                                                            } else {
                                                                                containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                                            }
                                                                        }

                                                                    }

                                                                }

                                                            }
                                                        } else {

                                                            dup = dup[keyArr[m]];
                                                            if (dup.constructor === [].constructor) {
                                                               // containMsg += "*: Not able to validate the " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key";
                                                               // break;
                                                               throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + "key response data is not validated");
                                                               
                                                            }
                                                            if (dup.constructor === "hello".constructor) {
                                                                throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + "key is not present");
                                                            }
                                                            console.log("dup********");
                                                            console.log(dup);
                                                        }
                                                    }


                                                }





                                            }
                                            console.log("before break");
                                            break;
                                        } else {

                                        }
                                    }
                                }

                            } else if (body.constructor === [].constructor) {
                                for (var n = 0; n < body.length; n++) {
                                    for (var i = 0; i < app.test_suites[counter].unitTest.configuration.jsonData.length; i++) {

                                        console.log("inside for loop " + app.test_suites[counter].unitTest.configuration.jsonData.length);
                                        keyArray = app.test_suites[counter].unitTest.configuration.jsonData[i].key.split(".");
                                        console.log("==========================");
                                        console.log(keyArray);
                                        var dupBody = body[n];
                                        for (var k = 0; k < keyArray.length; k++) {
                                            console.log(dupBody);
                                            console.log(keyArray[k]);
                                            if (dupBody.constructor === {}.constructor) {
                                                keyExist = false;
                                                for (var key in dupBody) {
                                                    console.log(key);
                                                    if (key == keyArray[k]) {
                                                        keyExist = true;
                                                        break;
                                                    }
                                                }
                                                if (keyExist == false) {
                                                    throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                                } else {
                                                    if (k + 1 == keyArray.length) {
                                                        console.log("equalled");
                                                        console.log(dupBody[keyArray[k]]);
                                                        console.log("key present " + keyArray[k]);
                                                        var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase();
                                                        if (app.test_suites[counter].unitTest.configuration.jsonData[i].type !== "") {
                                                            if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                                if (value === 'false') {
                                                                    assert.deepEqual(dupBody[keyArray[k]], false, "response data is not matched");
                                                                } else if (value === 'true') {
                                                                    assert.deepEqual(dupBody[keyArray[k]], true, "response data is not matched");
                                                                } else if (value === 'null') {
                                                                    assert.deepEqual(dupBody[keyArray[k]], null, "response data is not matched");
                                                                } else {
                                                                    assert.deepEqual(dupBody[keyArray[k]], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                                }

                                                            }
                                                            else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                                if (dupBody[keyArray[k]] == null || body[keyArray[k]] == "") {
                                                                    throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key value is not present");
                                                                } else {
                                                                    if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                                        if ((dupBody[keyArray[k]] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                                            console.log("matched");
                                                                            //containMsg = ""
                                                                        } else {
                                                                            containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                                        }
                                                                    }

                                                                }

                                                            }

                                                        }
                                                    } else {
                                                        dupBody = dupBody[keyArray[k]];
                                                        if (dupBody.constructor === "hello".constructor) {
                                                            throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is not present");
                                                        }
                                                        console.log("dupBody********");
                                                        console.log(dupBody);
                                                    }
                                                }
                                            } else if (dupBody.constructor === [].constructor) {

                                                //console.log("k value is "+k+" "+keyArray[k]+" "+keyArray.length);
                                                keyArr = [];
                                                for (var m = 0; keyArray.length > k; m++) {
                                                    console.log("k value is " + k + " " + keyArray[k] + " " + keyArray.length);
                                                    keyArr.push(keyArray[k]);
                                                    k = k + 1;
                                                }
                                                for (var j = 0; j < dupBody.length; j++) {
                                                    console.log("inside for loop " + dupBody.length);
                                                    //keyArray = req.body.unitTest.configuration.jsonData[i].key.split(".");
                                                    console.log("==========================");

                                                    //console.log(keyArray);
                                                    dup = dupBody[j];
                                                    console.log("dup==========================");
                                                    console.log(dup);
                                                    console.log("keyArr length " + keyArr.length);
                                                    for (var m = 0; m < keyArr.length; m++) {
                                                        keyExist = false;
                                                        for (var key in dup) {
                                                            console.log(key);
                                                            if (key == keyArr[m]) {
                                                                keyExist = true;
                                                                break;
                                                            }
                                                        }

                                                        if (keyExist == false) {
                                                            throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                                        } else {
                                                            if (m + 1 == keyArr.length) {
                                                                console.log("equalled");
                                                                console.log(dupBody[keyArray[k]]);
                                                                console.log("key present " + keyArray[k]);
                                                                var value = app.test_suites[counter].unitTest.configuration.jsonData[i].value.toLowerCase();
                                                                if (app.test_suites[counter].unitTest.configuration.jsonData[i].type !== "") {
                                                                    if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                                        if (value === 'false') {
                                                                            assert.deepEqual(dup[keyArr[m]], false, "response data is not matched");
                                                                        } else if (value === 'true') {
                                                                            assert.deepEqual(dup[keyArr[m]], true, "response data is not matched");
                                                                        } else if (value === 'null') {
                                                                            assert.deepEqual(dup[keyArr[m]], null, "response data is not matched");
                                                                        } else {
                                                                            assert.deepEqual(dup[keyArr[m]], app.test_suites[counter].unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                                        }

                                                                    }
                                                                    else if (app.test_suites[counter].unitTest.configuration.jsonData[i].type === "Contains") {
                                                                        if (dup[keyArr[m]] == null || dup[keyArr[m]] == "") {
                                                                            throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + "key value is not present");
                                                                        } else {
                                                                            if (app.test_suites[counter].unitTest.configuration.jsonData[i].value != "") {
                                                                                if ((dup[keyArr[m]] + "").includes(app.test_suites[counter].unitTest.configuration.jsonData[i].value)) {
                                                                                    console.log("matched");
                                                                                    //containMsg = ""
                                                                                } else {
                                                                                    containMsg += "*: " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is present but " + app.test_suites[counter].unitTest.configuration.jsonData[i].value + "is not present in value"
                                                                                }
                                                                            }

                                                                        }

                                                                    }

                                                                }
                                                            } else {

                                                                dup = dup[keyArr[m]];
                                                                if (dup.constructor === [].constructor) {
                                                                   // containMsg += "*: Not able to validate the " + app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key";
                                                                   // break;
                                                                   throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key response data is not validated");
                                                                }
                                                                if (dup.constructor === "hello".constructor) {
                                                                    throw Error(app.test_suites[counter].unitTest.configuration.jsonData[i].key + " key is not present");
                                                                }
                                                                console.log("dup********");
                                                                console.log(dup);
                                                            }
                                                        }


                                                    }





                                                }
                                                console.log("before break");
                                                break;
                                            } else {

                                            }

                                        }

                                    }
                                }
                            }

                            app.test_suites[counter].status = "Successfull";
                            app.test_suites[counter].statusMsg.push({ "time": new Date(), "message": "Successfull" });
                            app.test_suites[counter].unitTest.responseData = JSON.stringify(body);
                            if (counter + 1 < app.test_suites.length) {
                                hitApi(app.test_suites[counter + 1], app, counter + 1);
                            } else {
                                //server store
                                saveTest(app);

                            }
                        } else {
                            throw Error("reponse data is not valid json");
                        }
                    } else {

                    }

                } else {
                    console.log("response type is not given");
                    app.test_suites[counter].status = "Successfull";
                    app.test_suites[counter].statusMsg.push({ "time": new Date(), "message": "Successfull" });
                    app.test_suites[counter].unitTest.responseData = responseBody;
                    if (counter + 1 < app.test_suites.length) {
                        hitApi(app.test_suites[counter + 1], app, counter + 1);
                    } else {
                        //server store
                        saveTest(app);

                    }
                }